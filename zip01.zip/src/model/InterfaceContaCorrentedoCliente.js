class InterfaceContaCorrentedoCliente{

    constructor(SequenciadaConta, CodigodoCliente, CodigodaContaCorrente, CodigodoBanco, NomedoBanco, AgenciadoBanco, NomedaAgencia, EnderecodaAgencia, BairrodaAgencia, CidadedaAgencia, UFdaAgencia, CepdaAgencia, NumerodaContaBancaria, TipodeConta,Competencia, OperacaodeIntegracao){
            this.SequenciadaConta = SequenciadaConta
            this.CodigodoCliente = CodigodoCliente
            this.CodigodaContaCorrente = CodigodaContaCorrente
            this.CodigodoBanco = CodigodoBanco
            this.NomedoBanco = NomedoBanco
            this.AgenciadoBanco = AgenciadoBanco
            this.NomedaAgencia = NomedaAgencia
            this.EnderecodaAgencia = EnderecodaAgencia
            this.BairrodaAgencia = BairrodaAgencia
            this.CidadedaAgencia = CidadedaAgencia
            this.UFdaAgencia = UFdaAgencia
            this.CepdaAgencia = CepdaAgencia
            this.NumerodaContaBancaria = NumerodaContaBancaria
            this.TipodeConta = TipodeConta
            this.Competencia = Competencia
            this.OperacaodeIntegracao = OperacaodeIntegracao

    }
    
}

module.exports = InterfaceContaCorrentedoCliente
const Joi = require('joi');

const ambiente = {
    urlLocal : "http://localhost:3000",
    urlMarlin : "http://10.190.4.17:3000/api/v1/contratos",
    urlDEV : "",
    urlHML : ""
}

module.exports = {
    ambiente
}
